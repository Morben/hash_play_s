<div class="input-group input-group-sm quick-form-field">
    <input <?php echo $attributes; ?> placeholder="<?php echo e($label, false); ?>"/>
</div><?php /**PATH D:\phpstudy_pro\WWW\tgbots\vendor\dcat\laravel-admin\src/../resources/views/grid/quick-create/text.blade.php ENDPATH**/ ?>