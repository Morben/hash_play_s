<?php

return [
    'error_loading'    => '無法載入結果',
    'input_too_long'   => '請刪除:num個字符',
    'input_too_short'  => '請輸入至少:num個字符',
    'loading_more'     => '載入更多結果...',
    'maximum_selected' => '最多只能選擇:num個項目',
    'no_results'       => '未找到結果',
    'searching'        => '搜尋中...',
];
