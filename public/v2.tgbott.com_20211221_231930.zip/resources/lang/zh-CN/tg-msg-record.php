<?php 
return [
    'labels' => [
        'TgMsgRecord' => 'TgMsgRecord',
    ],
    'fields' => [
        'bot_id' => '机器人',
        'message_id' => '消息id',
        'type' => '消息类型',
        'username' => 'botname',
        'content' => '消息内容',
        'remark' => '备注',
    ],
    'options' => [
    ],
];
