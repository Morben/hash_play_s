<?php 
return [
    'labels' => [
        'TgGroup' => 'TgGroup',
    ],
    'fields' => [
        'bot_id' => 'bot_id',
        'chat_id' => '群id',
        'title' => '群名称',
        'remark' => '备注',
    ],
    'options' => [
    ],
];
