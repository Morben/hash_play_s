<?php 
return [
    'labels' => [
        'TgBot' => 'TgBot',
    ],
    'fields' => [
        'bot_id' => 'bot_id',
        'username' => 'botname',
        'can_join_groups' => '是否能加群组',
        'can_read_all_group_messages' => '是否能获取群聊信息',
        'supports_inline_queries' => '是否内联',
        'remark' => '备注',
    ],
    'options' => [

    ],
];
