<?php 
return [
    'labels' => [
        'TgKeyword' => 'TgKeyword',
    ],
    'fields' => [
        'bot_id' => 'bot_id',
        'keyword' => '触发词',
        'type' => '操作类型',
        'content' => '回复内容',
        'status' => '状态',
        'remark' => '备注',
    ],
    'options' => [
    ],
];
